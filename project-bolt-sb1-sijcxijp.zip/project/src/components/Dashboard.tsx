import { useEffect, useState } from 'react';
import { Plus, TrendingUp, Thermometer, Gauge } from 'lucide-react';
import { supabase, PyrolysisEvent } from '../lib/supabase';

interface DashboardProps {
  onNewEvent: () => void;
  refreshTrigger: number;
}

export default function Dashboard({ onNewEvent, refreshTrigger }: DashboardProps) {
  const [dailyEvents, setDailyEvents] = useState<PyrolysisEvent[]>([]);
  const [weeklyEvents, setWeeklyEvents] = useState<PyrolysisEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [refreshTrigger]);

  const loadData = async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0];

      const { data: daily } = await supabase
        .from('pyrolysis_events')
        .select('*')
        .eq('fecha_registro', today)
        .order('created_at', { ascending: false });

      const { data: weekly } = await supabase
        .from('pyrolysis_events')
        .select('*')
        .gte('fecha_registro', weekAgo)
        .order('fecha_registro', { ascending: false });

      setDailyEvents(daily || []);
      setWeeklyEvents(weekly || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateAverage = (events: PyrolysisEvent[], field: keyof PyrolysisEvent) => {
    if (events.length === 0) return 0;
    const sum = events.reduce((acc, event) => acc + Number(event[field]), 0);
    return (sum / events.length).toFixed(1);
  };

  const avgDailyTemp =
    calculateAverage(dailyEvents, 'temperatura_reactor');
  const avgWeeklyTemp =
    calculateAverage(weeklyEvents, 'temperatura_reactor');
  const avgDailyPressure =
    calculateAverage(dailyEvents, 'presion_inicial');
  const avgWeeklyPressure =
    calculateAverage(weeklyEvents, 'presion_inicial');

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-black mb-2">Dashboard</h2>
          <p className="text-gray-600">Resumen de eventos de pirólisis</p>
        </div>
        <button
          onClick={onNewEvent}
          className="bg-[#FF8C69] text-white px-6 py-3 rounded-lg hover:bg-[#ff9d7f] transition-all font-medium flex items-center gap-2"
        >
          <Plus size={20} />
          Registrar Nuevo Evento
        </button>
      </div>

      {loading ? (
        <div className="text-center text-black py-12">Cargando datos...</div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-br from-[#FF8C69]/10 to-[#FF8C69]/5 border border-gray-200 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="text-[#FF8C69]" size={24} />
                <h3 className="text-black font-medium">Eventos Hoy</h3>
              </div>
              <p className="text-4xl font-bold text-black">{dailyEvents.length}</p>
            </div>

            <div className="bg-gradient-to-br from-[#FF8C69]/10 to-[#FF8C69]/5 border border-gray-200 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="text-[#FF8C69]" size={24} />
                <h3 className="text-black font-medium">Eventos Semana</h3>
              </div>
              <p className="text-4xl font-bold text-black">{weeklyEvents.length}</p>
            </div>

            <div className="bg-gradient-to-br from-[#FF8C69]/10 to-[#FF8C69]/5 border border-gray-200 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-2">
                <Thermometer className="text-[#FF8C69]" size={24} />
                <h3 className="text-black font-medium">Temp. Prom. Hoy</h3>
              </div>
              <p className="text-4xl font-bold text-black">{avgDailyTemp}°C</p>
            </div>

            <div className="bg-gradient-to-br from-[#FF8C69]/10 to-[#FF8C69]/5 border border-gray-200 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-2">
                <Gauge className="text-[#FF8C69]" size={24} />
                <h3 className="text-black font-medium">Presión Prom. Hoy</h3>
              </div>
              <p className="text-4xl font-bold text-black">{avgDailyPressure} PSI</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-bold text-black mb-4">
                Resumen Semanal - Temperatura
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Promedio Reactor:</span>
                  <span className="font-bold text-[#FF8C69]">{avgWeeklyTemp}°C</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Promedio Caldera:</span>
                  <span className="font-bold text-[#FF8C69]">
                    {calculateAverage(weeklyEvents, 'temperatura_caldera')}°C
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Promedio Agua:</span>
                  <span className="font-bold text-[#FF8C69]">
                    {calculateAverage(weeklyEvents, 'temperatura_agua')}°C
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-bold text-black mb-4">
                Resumen Semanal - Presión
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Promedio:</span>
                  <span className="font-bold text-[#FF8C69]">
                    {avgWeeklyPressure} PSI
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Total Eventos:</span>
                  <span className="font-bold text-[#FF8C69]">{weeklyEvents.length}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
            <h3 className="text-xl font-bold text-black mb-4">Eventos de Hoy</h3>
            {dailyEvents.length === 0 ? (
              <p className="text-gray-600 text-center py-8">
                No hay eventos registrados hoy
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left text-[#FF8C69] py-3 px-4 font-semibold">Producto</th>
                      <th className="text-left text-[#FF8C69] py-3 px-4 font-semibold">Temp. Reactor</th>
                      <th className="text-left text-[#FF8C69] py-3 px-4 font-semibold">Presión</th>
                      <th className="text-left text-[#FF8C69] py-3 px-4 font-semibold">Observación</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dailyEvents.map((event) => (
                      <tr
                        key={event.id}
                        className="border-b border-gray-100 hover:bg-[#FF8C69]/5"
                      >
                        <td className="text-black py-3 px-4">{event.producto_pirolisis}</td>
                        <td className="text-black py-3 px-4">
                          {event.temperatura_reactor}°C
                        </td>
                        <td className="text-black py-3 px-4">{event.presion_inicial} PSI</td>
                        <td className="text-gray-600 py-3 px-4 max-w-xs truncate">
                          {event.observacion || '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
