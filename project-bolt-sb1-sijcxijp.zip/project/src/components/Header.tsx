export default function Header() {
  return (
    <header className="bg-white border-b border-gray-200 py-6 px-8">
      <div className="max-w-7xl mx-auto flex items-center gap-4">
        <img
          src="/poligas-logo.png"
          alt="Poligas Chile"
          className="h-16 w-16 object-contain"
          style={{ filter: 'hue-rotate(320deg) saturate(1.5) brightness(1.1)' }}
        />
        <div>
          <h1 className="text-3xl font-bold text-black">Poligas Chile</h1>
          <p className="text-[#FF8C69] text-sm">Ecological Pyrolysis Logbook</p>
        </div>
      </div>
    </header>
  );
}
