import { useState } from 'react';
import { X } from 'lucide-react';
import { supabase, PyrolysisEvent } from '../lib/supabase';

interface EventFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

export default function EventForm({ onClose, onSuccess }: EventFormProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fecha_registro: new Date().toISOString().split('T')[0],
    producto_pirolisis: 'Gas pirolítico' as PyrolysisEvent['producto_pirolisis'],
    temperatura_caldera: '',
    temperatura_reactor: '',
    temperatura_gases_reactor: '',
    temperatura_agua: '',
    temperatura_liquido: '',
    presion_inicial: '',
    observacion: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.from('pyrolysis_events').insert([
        {
          fecha_registro: formData.fecha_registro,
          producto_pirolisis: formData.producto_pirolisis,
          temperatura_caldera: parseFloat(formData.temperatura_caldera),
          temperatura_reactor: parseFloat(formData.temperatura_reactor),
          temperatura_gases_reactor: parseFloat(formData.temperatura_gases_reactor),
          temperatura_agua: parseFloat(formData.temperatura_agua),
          temperatura_liquido: parseFloat(formData.temperatura_liquido),
          presion_inicial: parseFloat(formData.presion_inicial),
          observacion: formData.observacion.slice(0, 500),
        },
      ]);

      if (error) throw error;

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving event:', error);
      alert('Error al guardar el evento');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-gray-200 shadow-xl">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-black">Registrar Nuevo Evento</h2>
          <button
            onClick={onClose}
            className="text-black hover:text-[#FF8C69] transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-black mb-2 text-sm font-medium">
              Fecha de Registro
            </label>
            <input
              type="date"
              required
              value={formData.fecha_registro}
              onChange={(e) =>
                setFormData({ ...formData, fecha_registro: e.target.value })
              }
              className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
            />
          </div>

          <div>
            <label className="block text-black mb-2 text-sm font-medium">
              Producto a Pirolisar
            </label>
            <select
              required
              value={formData.producto_pirolisis}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  producto_pirolisis: e.target.value as PyrolysisEvent['producto_pirolisis'],
                })
              }
              className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
            >
              <option value="Gas pirolítico">Gas pirolítico</option>
              <option value="Aceite pirolítico">Aceite pirolítico</option>
              <option value="Carbón sólido">Carbón sólido</option>
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-black mb-2 text-sm font-medium">
                Temperatura Caldera (°C)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.temperatura_caldera}
                onChange={(e) =>
                  setFormData({ ...formData, temperatura_caldera: e.target.value })
                }
                className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
              />
            </div>

            <div>
              <label className="block text-black mb-2 text-sm font-medium">
                Temperatura Reactor (°C)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.temperatura_reactor}
                onChange={(e) =>
                  setFormData({ ...formData, temperatura_reactor: e.target.value })
                }
                className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
              />
            </div>

            <div>
              <label className="block text-black mb-2 text-sm font-medium">
                Temperatura Gases del Reactor (°C)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.temperatura_gases_reactor}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    temperatura_gases_reactor: e.target.value,
                  })
                }
                className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
              />
            </div>

            <div>
              <label className="block text-black mb-2 text-sm font-medium">
                Temperatura del Agua (°C)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.temperatura_agua}
                onChange={(e) =>
                  setFormData({ ...formData, temperatura_agua: e.target.value })
                }
                className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
              />
            </div>

            <div>
              <label className="block text-black mb-2 text-sm font-medium">
                Temperatura del Líquido (°C)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.temperatura_liquido}
                onChange={(e) =>
                  setFormData({ ...formData, temperatura_liquido: e.target.value })
                }
                className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
              />
            </div>

            <div>
              <label className="block text-black mb-2 text-sm font-medium">
                Presión Inicial (PSI)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.presion_inicial}
                onChange={(e) =>
                  setFormData({ ...formData, presion_inicial: e.target.value })
                }
                className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-black focus:outline-none focus:border-[#FF8C69]"
              />
            </div>
          </div>

          <div>
            <label className="block text-black mb-2 text-sm font-medium">
              Observación ({formData.observacion.length}/500 caracteres)
            </label>
            <textarea
              value={formData.observacion}
              onChange={(e) =>
                setFormData({ ...formData, observacion: e.target.value })
              }
              maxLength={500}
              rows={4}
              className="w-full bg-black border border-[#FF8C69]/30 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#FF8C69] resize-none"
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-white border border-gray-300 text-black px-6 py-3 rounded-lg hover:bg-gray-50 transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-[#FF8C69] text-white px-6 py-3 rounded-lg hover:bg-[#ff9d7f] transition-all font-medium disabled:opacity-50"
            >
              {loading ? 'Guardando...' : 'Guardar Evento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
