import { useState } from 'react';
import { LayoutDashboard, List } from 'lucide-react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import EventList from './components/EventList';
import EventForm from './components/EventForm';

function App() {
  const [activeView, setActiveView] = useState<'dashboard' | 'events'>('dashboard');
  const [showEventForm, setShowEventForm] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleEventSuccess = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <nav className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-8 py-4 flex gap-4">
          <button
            onClick={() => setActiveView('dashboard')}
            className={`px-6 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
              activeView === 'dashboard'
                ? 'bg-[#FF8C69] text-white'
                : 'bg-white border border-gray-300 text-black hover:bg-gray-50'
            }`}
          >
            <LayoutDashboard size={20} />
            Dashboard
          </button>
          <button
            onClick={() => setActiveView('events')}
            className={`px-6 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
              activeView === 'events'
                ? 'bg-[#FF8C69] text-white'
                : 'bg-white border border-gray-300 text-black hover:bg-gray-50'
            }`}
          >
            <List size={20} />
            Eventos
          </button>
        </div>
      </nav>

      <main>
        {activeView === 'dashboard' ? (
          <Dashboard
            onNewEvent={() => setShowEventForm(true)}
            refreshTrigger={refreshTrigger}
          />
        ) : (
          <EventList refreshTrigger={refreshTrigger} />
        )}
      </main>

      {showEventForm && (
        <EventForm
          onClose={() => setShowEventForm(false)}
          onSuccess={handleEventSuccess}
        />
      )}
    </div>
  );
}

export default App;
