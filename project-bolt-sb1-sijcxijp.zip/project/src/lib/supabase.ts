import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface PyrolysisEvent {
  id?: string;
  fecha_registro: string;
  producto_pirolisis: 'Gas pirolítico' | 'Aceite pirolítico' | 'Carbón sólido';
  temperatura_caldera: number;
  temperatura_reactor: number;
  temperatura_gases_reactor: number;
  temperatura_agua: number;
  temperatura_liquido: number;
  presion_inicial: number;
  observacion: string;
  created_at?: string;
}
