/*
  # Create Pyrolysis Events Table

  1. New Tables
    - `pyrolysis_events`
      - `id` (uuid, primary key)
      - `fecha_registro` (date) - Registration date
      - `producto_pirolisis` (text) - Product type: Gas pirolítico, Aceite pirolítico, or Carbón sólido
      - `temperatura_caldera` (numeric) - Boiler temperature in °C
      - `temperatura_reactor` (numeric) - Reactor temperature in °C
      - `temperatura_gases_reactor` (numeric) - Reactor gases temperature in °C
      - `temperatura_agua` (numeric) - Water temperature in °C
      - `temperatura_liquido` (numeric) - Liquid temperature in °C
      - `presion_inicial` (numeric) - Initial pressure in PSI
      - `observacion` (text) - Observations (max 500 characters)
      - `created_at` (timestamptz) - Record creation timestamp

  2. Security
    - Enable RLS on `pyrolysis_events` table
    - Add policy for public access to read all events
    - Add policy for public access to insert new events
    - Add policy for public access to update events
    - Add policy for public access to delete events

  3. Notes
    - All temperature fields are in Celsius
    - Pressure field is in PSI
    - Date format will be handled in the application layer
    - Observations limited to 500 characters at application level
*/

CREATE TABLE IF NOT EXISTS pyrolysis_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fecha_registro date NOT NULL,
  producto_pirolisis text NOT NULL CHECK (producto_pirolisis IN ('Gas pirolítico', 'Aceite pirolítico', 'Carbón sólido')),
  temperatura_caldera numeric NOT NULL,
  temperatura_reactor numeric NOT NULL,
  temperatura_gases_reactor numeric NOT NULL,
  temperatura_agua numeric NOT NULL,
  temperatura_liquido numeric NOT NULL,
  presion_inicial numeric NOT NULL,
  observacion text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE pyrolysis_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access"
  ON pyrolysis_events
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public insert access"
  ON pyrolysis_events
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public update access"
  ON pyrolysis_events
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete access"
  ON pyrolysis_events
  FOR DELETE
  TO public
  USING (true);

CREATE INDEX IF NOT EXISTS idx_pyrolysis_events_fecha ON pyrolysis_events(fecha_registro DESC);
CREATE INDEX IF NOT EXISTS idx_pyrolysis_events_producto ON pyrolysis_events(producto_pirolisis);